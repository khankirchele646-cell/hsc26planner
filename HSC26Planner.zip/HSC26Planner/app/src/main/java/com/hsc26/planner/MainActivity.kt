package com.hsc26.planner

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var wv: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        val result: Array<Uri>? = if (r.resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) Array(clip.itemCount) { clip.getItemAt(it).uri }
            else data.data?.let { arrayOf(it) }
        } else null
        fileCb?.onReceiveValue(result)
        fileCb = null
    }

    inner class Bridge {
        @JavascriptInterface
        fun save(b64: String, name: String) {
            try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, "application/json")
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    dir.mkdirs()
                    File(dir, name).writeBytes(bytes)
                }
                runOnUiThread { Toast.makeText(this@MainActivity, "ব্যাকআপ Downloads ফোল্ডারে সেভ হয়েছে: $name", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "ব্যাকআপ সেভ করা যায়নি", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF6366F1.toInt()
        if (Build.VERSION.SDK_INT < 29)
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        wv = WebView(this)
        setContentView(wv)
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
        }
        wv.addJavascriptInterface(Bridge(), "Android")

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "appassets.androidplatform.net") return false
                if (u.scheme == "blob") return true
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) {}
                return true
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try { chooser.launch(i); true } catch (e: Exception) { fileCb = null; false }
            }
        }

        wv.setDownloadListener { url, _, _, _, _ ->
            if (url.startsWith("blob:")) {
                val name = "hsc26-backup-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".json"
                wv.evaluateJavascript(
                    "fetch('$url').then(r=>r.blob()).then(b=>{const f=new FileReader();" +
                        "f.onload=()=>Android.save(f.result.split(',')[1],'$name');f.readAsDataURL(b)})", null
                )
            }
        }

        onBackPressedDispatcher.addCallback(this) {
            if (wv.canGoBack()) wv.goBack() else finish()
        }

        if (b == null) wv.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        else wv.restoreState(b)
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); wv.saveState(o) }
}
